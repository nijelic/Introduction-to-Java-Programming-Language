package hr.fer.zemris.java.custom.scripting.elems;
/**
 * Elements will be used to for the representation of expressions.
 * @author Jelić, Nikola
 */
public class Element {

  /**
   * Returns string of element.
   * @return String
   * */
  public String asText() {
    return "";
  }
  
}
