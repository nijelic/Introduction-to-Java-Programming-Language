/**
 * Nodes will be used for representation of structured documents.<br>
 * <br>
 * Node<br>
 * Base class.<br>
 * <br>
 * DocumentNode<br>
 * Document node is top node of parsing tree.<br>
 * <br>
 * TextNode<br>
 * Text node is used for parsing tree.<br>
 * <br>
 * ForLoopNode<br>
 * For-loop node of parsing tree.<br>
 * <br>
 * EchoNode<br>
 * Echo node of parsing tree.<br>
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.custom.scripting.nodes;