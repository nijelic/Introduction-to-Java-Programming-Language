/**
 * Element<br>
 * Elements will be used to for the representation of expressions.<br>
 * <br>
 * ElementFunction<br>
 * Element of function used for parsing.<br>
 * <br>
 * ElementOperator<br>
 * Element of operator used for parsing.<br>
 * <br>
 * ElementString<br>
 * Element of string used for parsing.<br>
 * <br>
 * ElementVariable<br>
 * Element of variable used for parsing.<br>
 * <br>
 * ElementConstantDouble<br>
 * Element of double constant used for parsing.<br>
 * <br>
 * ElementConstantInteger<br>
 * Element of integer constant used for parsing.<br>
 * 
 * @author Jelić, Nikola
 */
package hr.fer.zemris.java.custom.scripting.elems;