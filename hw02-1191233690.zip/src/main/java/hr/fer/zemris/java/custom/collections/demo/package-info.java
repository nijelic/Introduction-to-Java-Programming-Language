/**
 * StackDemo - Postfix Arithmetics
 * Application that simulates Stack manipulations.
 * 
 * @author Jelić, Nikola
 */
package hr.fer.zemris.java.custom.collections.demo;