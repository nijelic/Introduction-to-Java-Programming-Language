/**
 * This package conatins:<br>
 * <br>
 * ComplexNumber<br>
 * Class that represents an unmodifiable complex number
 * with appropriate methods.
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.hw02;