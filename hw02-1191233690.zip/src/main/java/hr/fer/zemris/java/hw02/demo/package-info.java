/**
 * Package contains demo application for complex numbers.
 * 
 * @author unknown
 */
package hr.fer.zemris.java.hw02.demo;