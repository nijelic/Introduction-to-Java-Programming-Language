/**
 * Ignore this package.
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.hw06.shell.demo;