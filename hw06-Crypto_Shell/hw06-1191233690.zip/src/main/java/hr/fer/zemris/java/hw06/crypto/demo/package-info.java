/**
 * IGNORE this package.
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.hw06.crypto.demo;