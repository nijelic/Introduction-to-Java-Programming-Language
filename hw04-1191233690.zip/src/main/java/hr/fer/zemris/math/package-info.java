/**
 * This package contains:<br>
 * <br>
 * Vector2D <br>
 * Vector2D models 2D vectors with its 
 * possibilities of scaling, translating and rotating.
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.math;