/**
 * Package with examples.
 * 
 * @author Jelić, Nikola
 */
package hr.fer.zemris.java.custom.collections.demo;