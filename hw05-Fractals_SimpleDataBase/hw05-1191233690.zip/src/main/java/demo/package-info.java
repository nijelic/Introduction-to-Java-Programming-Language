/**
 * This package has some simulations.
 * @author Jelić, Nikola
 *
 */
package demo;