/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.math.Complex}
 * 
 * {@link hr.fer.zemris.math.ComplexRootedPolynomial}
 * 
 * {@link hr.fer.zemris.math.ComplexPolynomial}
 * 
 * {@link hr.fer.zemris.math.Vector3}
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.math;