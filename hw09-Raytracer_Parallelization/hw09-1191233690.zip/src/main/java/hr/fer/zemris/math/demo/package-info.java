/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.math.demo.Demo1}
 * 
 * {@link hr.fer.zemris.math.demo.Demo2}
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.math.demo;