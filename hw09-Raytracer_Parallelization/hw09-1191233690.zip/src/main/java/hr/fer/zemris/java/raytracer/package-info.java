/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.raytracer.RayCaster}
 * 
 * {@link hr.fer.zemris.java.raytracer.RayCasterParallel}
 * 
 * {@link hr.fer.zemris.java.raytracer.RayCasterParallel2}
 * 
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.raytracer;