/**
 * This package conatins:
 * 
 * {@link hr.fer.zemris.java.fractals.NewtonRaphson}
 * 
 * {@link hr.fer.zemris.java.fractals.Newton}
 *
 * @author Jelić, Nikola
 */
package hr.fer.zemris.java.fractals;