package hr.fer.zemris.java.hw17.jvdraw;

/**
 * Enumerator that has Line, Circle and Filled Circle
 * 
 * @author Jelić, Nikola
 */
public enum DrawingType {
LINE,
CIRCLE,
FILLEDCIRCLE	
}
