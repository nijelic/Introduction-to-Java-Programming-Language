/**
 * SmartScriptTest <br>
 * Used for testing SmartScriptParser<br>
 *
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.hw03;