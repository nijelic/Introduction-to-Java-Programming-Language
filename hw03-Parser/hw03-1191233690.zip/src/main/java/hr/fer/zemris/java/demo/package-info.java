/**
 * This package contains demo/test applications.<br>
 * 
 * @author Jelić, Nikola
 */
package hr.fer.zemris.java.demo;