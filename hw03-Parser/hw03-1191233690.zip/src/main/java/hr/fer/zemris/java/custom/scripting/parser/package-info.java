/**
 * SmartScriptParser<br>
 * Parser for simple script language-<br>
 * <br>-<br>
 *
 * SmartScriptParserException<br>
 * Used for {@link SmartScriptParser}.<br>
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.custom.scripting.parser;