/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.gui.charts.BarChart}
 * 
 * {@link hr.fer.zemris.java.gui.charts.BarChartDemo}
 * 
 * {@link hr.fer.zemris.java.gui.charts.BarChartComponent}
 * 
 * {@link hr.fer.zemris.java.gui.charts.XYValue}
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.gui.charts;