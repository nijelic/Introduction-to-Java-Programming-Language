/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.gui.prim.PrimDemo}
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.gui.prim;