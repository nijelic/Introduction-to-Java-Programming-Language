/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.gui.calc.CalcModelImpl}
 * 
 * {@link hr.fer.zemris.java.gui.calc.Calculator}
 *
 * @author Jelić, Nikola
 */
package hr.fer.zemris.java.gui.calc;