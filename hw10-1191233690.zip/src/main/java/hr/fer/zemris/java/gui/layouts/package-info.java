/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.gui.layouts.CalcLayout}
 * 
 * {@link hr.fer.zemris.java.gui.layouts.CalcLayoutException}
 * 
 * {@link hr.fer.zemris.java.gui.layouts.RCPosition}
 * 
 * @author JElić, Nikola
 *
 */
package hr.fer.zemris.java.gui.layouts;