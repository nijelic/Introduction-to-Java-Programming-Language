/**
 * This package contains:
 * 
 * {@link searching.demo.SlagalicaDemo}
 * 
 * {@link searching.demo.SlagalicaMain}
 * 
 * 
 * @author Jelić, Nikola
 *
 */
package searching.demo;