/**
 * This package contains:
 * 
 * {@link searching.slagalica.KonfiguracijaSlagalice}
 * 
 * {@link searching.slagalica.Slagalica}
 * 
 * @author nikola
 *
 */
package searching.slagalica;