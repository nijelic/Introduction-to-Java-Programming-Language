/**
 * This package contains: 
 * 
 * {@link searching.algorithms.Node}
 * 
 * {@link searching.algorithms.SearchUtil}
 * 
 * {@link searching.algorithms.Transition}
 * 
 * @author Jelić, Nikola
 *
 */
package searching.algorithms;