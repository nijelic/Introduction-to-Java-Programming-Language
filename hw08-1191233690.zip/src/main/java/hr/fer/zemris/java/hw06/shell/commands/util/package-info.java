/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.hw06.shell.commands.util.FilterResult}
 * 
 * {@link hr.fer.zemris.java.hw06.shell.commands.util.NameBuilder}
 * 
 * {@link hr.fer.zemris.java.hw06.shell.commands.util.NameBuilderParser}
 * 
 * {@link hr.fer.zemris.java.hw06.shell.commands.util.Utility}
 *
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.hw06.shell.commands.util;