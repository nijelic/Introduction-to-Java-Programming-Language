package hr.fer.zemris.java.hw06.shell;

/**
 * ShellStatus is used for determination of status.
 * Status can be CONTINUE or TERMINATE.
 * */
public enum ShellStatus {
	CONTINUE, TERMINATE
}
