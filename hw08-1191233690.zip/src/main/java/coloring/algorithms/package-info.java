/**
 * This package contains: 
 * {@link coloring.algorithms.Coloring}
 * 
 * {@link coloring.algorithms.Pixel}
 * 
 * {@link coloring.algorithms.SubspaceExploreUtil}
 * 
 * @author Jelić, Nikola
 *
 */
package coloring.algorithms;