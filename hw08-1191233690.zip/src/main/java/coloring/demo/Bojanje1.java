package coloring.demo;

import marcupic.opjj.statespace.coloring.FillApp;

/**
 * Example no. 1
 * */
public class Bojanje1 {

	/**
	 * Main method
	 * */
	public static void main(String[] args) {
		FillApp.run(FillApp.OWL, null); // ili FillApp.ROSE
		}
}
