/**
 * This package contains:
 * 
 * {@link coloring.demo.Bojanje1}
 * 
 * {@link coloring.demo.Bojanje2}
 * 
 * @author Jelić, Nikola
 *
 */
package coloring.demo;