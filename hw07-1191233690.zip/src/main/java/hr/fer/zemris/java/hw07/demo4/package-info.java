/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.hw07.demo4.StudentRecord}
 * 
 *  {@link hr.fer.zemris.java.hw07.demo4.StudentDemo}
 *
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.hw07.demo4;