/**
 * This package contains:
 * 
 * {@link hr.fer.zemris.java.custom.scripting.demo.ObjectMultistackDemo}
 * {@link hr.fer.zemris.java.custom.scripting.demo.ObjectMultistackDemo2}
 *
 */
package hr.fer.zemris.java.custom.scripting.demo;