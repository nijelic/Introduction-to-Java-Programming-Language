/**
 * This package contains:
 * 
 *  {@link hr.fer.zemris.java.custom.scripting.exec.ObjectMultistack}
 *  
 *  {@link hr.fer.zemris.java.custom.scripting.exec.ValueWrapper}
 *
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.custom.scripting.exec;