/**
 * This package contains: <br/>
 * <br/>
 *
 * {@link hr.fer.zemris.java.hw07.demo2.PrimesCollection} <br/>
 * {@link hr.fer.zemris.java.hw07.demo2.PrimesDemo1} <br/>
 * {@link hr.fer.zemris.java.hw07.demo2.PrimesDemo2} <br/>
 * 
 * @author Jelić, Nikola
 *
 */
package hr.fer.zemris.java.hw07.demo2;